/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package tugas2;

/**
 *
 * @author bachtiar
 */
public interface fungsi {
    void telpon(String nomor);
    void sms (String nomor,String pesan);
}
